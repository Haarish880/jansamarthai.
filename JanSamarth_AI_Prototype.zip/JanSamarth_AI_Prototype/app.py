from flask import Flask, request, render_template_string, redirect, url_for, flash
import sqlite3
from pathlib import Path
from datetime import datetime
import os

APP_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("JANSMARTH_DB", APP_DIR / "grievances.db"))
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-only-change-me")

HTML = """
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>JanSamarth AI | Civic Grievance Assistant</title>
<style>
:root{font-family:Arial,sans-serif;color:#182230;background:#f4f7fb}
body{margin:0}.hero{background:#123a70;color:white;padding:28px max(20px,calc((100% - 1000px)/2))}
main{max-width:1000px;margin:24px auto;padding:0 16px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.card{background:white;border:1px solid #dbe3ef;border-radius:14px;padding:20px;box-shadow:0 3px 12px #17365d0b}
label{display:block;font-weight:700;margin:12px 0 6px}input,select,textarea{box-sizing:border-box;width:100%;padding:11px;border:1px solid #bac7d8;border-radius:8px;font:inherit}
textarea{min-height:100px}button{margin-top:14px;padding:11px 16px;border:0;border-radius:8px;background:#1764c0;color:white;font-weight:700;cursor:pointer}
.muted{color:#637083;font-size:.9rem}.tag{display:inline-block;background:#e7f1ff;color:#154b87;padding:4px 8px;border-radius:20px;font-size:.8rem}
.item{padding:12px 0;border-bottom:1px solid #e8edf4}.item:last-child{border-bottom:0}.notice{background:#fff7df;border:1px solid #f0d68a;padding:10px;border-radius:8px}
@media(max-width:720px){.grid{grid-template-columns:1fr}}
</style></head>
<body>
<header class="hero"><h1>JanSamarth AI</h1><p>Automated Grievance &amp; Civic Response System</p><span class="tag">Prototype demonstration</span></header>
<main>
{% with messages = get_flashed_messages() %}{% if messages %}<div class="notice">{% for m in messages %}<p>{{m}}</p>{% endfor %}</div>{% endif %}{% endwith %}
<div class="grid">
<section class="card"><h2>Submit a civic grievance</h2>
<p class="muted">Describe a local civic issue. Do not enter passwords, Aadhaar numbers, or other sensitive personal information.</p>
<form method="post" action="/submit">
<label for="name">Name (optional)</label><input id="name" name="name" maxlength="80" placeholder="Your name">
<label for="category">Issue category</label><select id="category" name="category" required>
<option value="">Choose a category</option><option>Roads</option><option>Water Supply</option><option>Sanitation</option><option>Streetlights</option><option>Waste Management</option><option>Public Safety</option><option>Other</option></select>
<label for="location">Area / locality</label><input id="location" name="location" maxlength="120" required placeholder="e.g., Main Road, Ward 4">
<label for="description">Describe the issue</label><textarea id="description" name="description" maxlength="2000" required placeholder="What happened, and where?"></textarea>
<button type="submit">Submit grievance</button></form></section>
<section class="card"><h2>Recent submissions</h2><p class="muted">Demo records stored locally in SQLite on this computer.</p>
{% if grievances %}{% for g in grievances %}<div class="item"><strong>#{{g[0]}} — {{g[2]}}</strong> <span class="tag">{{g[5]}}</span><p>{{g[3]}}</p><p class="muted">{{g[4]}} · {{g[6]}}</p><p><strong>Suggested next step:</strong> {{g[7]}}</p></div>{% endfor %}{% else %}<p>No grievances submitted yet.</p>{% endif %}
</section></div>
<p class="muted">This is a student prototype, not an official government service. Priority and next-step suggestions are rule-based demonstrations; no complaint is sent to a government department.</p>
</main></body></html>
"""

def connect():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS grievances (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, category TEXT NOT NULL,
        location TEXT NOT NULL, description TEXT NOT NULL, priority TEXT NOT NULL,
        created_at TEXT NOT NULL, suggestion TEXT NOT NULL)""")
    con.commit()
    return con

def triage(category, description):
    text = description.lower()
    urgent_words = ["fire", "danger", "electric shock", "live wire", "collapse", "accident", "unsafe"]
    if any(word in text for word in urgent_words) or category == "Public Safety":
        return "High", "If there is immediate danger, contact the appropriate emergency service. Then report the issue to the relevant local authority."
    suggestions = {
        "Roads": "Record the exact location and, if safe, a photo; submit it to the local roads/municipal department.",
        "Water Supply": "Note the affected street and duration; contact the local water-supply authority.",
        "Sanitation": "Record the location and time; report it to the municipal sanitation team.",
        "Streetlights": "Provide the pole number or nearest landmark to the local electricity/municipal office.",
        "Waste Management": "Share the collection point and dates missed with the local municipal waste team.",
        "Other": "Identify the responsible local department and ask for a grievance reference number."
    }
    return "Normal", suggestions.get(category, "Contact the relevant local civic authority and keep the grievance reference number.")

@app.get("/")
def index():
    con = connect()
    rows = con.execute("SELECT id,name,category,location,description,priority,created_at,suggestion FROM grievances ORDER BY id DESC LIMIT 10").fetchall()
    con.close()
    return render_template_string(HTML, grievances=rows)

@app.post("/submit")
def submit():
    name = request.form.get("name", "").strip()[:80]
    category = request.form.get("category", "").strip()
    location = request.form.get("location", "").strip()[:120]
    description = request.form.get("description", "").strip()[:2000]
    allowed = {"Roads","Water Supply","Sanitation","Streetlights","Waste Management","Public Safety","Other"}
    if category not in allowed or not location or not description:
        flash("Please choose a category and provide both location and description.")
        return redirect(url_for("index"))
    priority, suggestion = triage(category, description)
    con = connect()
    con.execute("INSERT INTO grievances(name,category,location,description,priority,created_at,suggestion) VALUES(?,?,?,?,?,?,?)",
                (name,category,location,description,priority,datetime.now().strftime("%Y-%m-%d %H:%M"),suggestion))
    con.commit()
    con.close()
    flash(f"Grievance recorded in the local demo. Suggested priority: {priority}. This was not sent to an authority.")
    return redirect(url_for("index"))

if __name__ == "__main__":
    connect().close()
    app.run(debug=True)
