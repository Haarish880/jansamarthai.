# Technical Design Document

## 1. Purpose
JanSamarth AI is intended to help residents describe civic issues in a consistent format and receive a suggested next step. This repository is an educational proof-of-concept, not an official grievance channel.

## 2. Architecture
```text
Resident
   |
   v
Browser form (HTML/CSS)
   |
   v
Flask routes (/ and /submit)
   |
   +--> Input validation
   |
   +--> Rule-based triage (category + keyword checks)
   |
   v
SQLite database (local file)
   |
   v
Recent-submissions view + suggested next step
```

## 3. Components
- **Presentation:** HTML rendered by Flask; responsive form and recent-submission list.
- **Application:** Python Flask routes validate form fields and process submissions.
- **Triage:** `triage()` maps categories and a small set of urgent keywords to demo priority/suggestions.
- **Storage:** SQLite table `grievances`; local-only storage in this prototype.

## 4. Data model
| Field | Type | Notes |
|---|---|---|
| id | integer | Auto-increment primary key |
| name | text | Optional display name; avoid personal data |
| category | text | Validated category |
| location | text | Locality or landmark |
| description | text | Up to 2,000 characters |
| priority | text | Rule-based `High` or `Normal` |
| created_at | text | Local timestamp |
| suggestion | text | Rule-based guidance |

## 5. Security and limitations
- No authentication, role-based access, encryption-at-rest, rate limiting, or production monitoring.
- No government API integration or automatic forwarding.
- Rules are illustrative and can misclassify issues; urgent cases should be handled by appropriate official emergency channels.
- For a real deployment, add privacy notices, data minimization, retention/deletion controls, secure hosting, access controls, audit logging, validation, abuse protection, accessibility testing, and expert/legal review.

## 6. Planned improvements
1. Multilingual Tamil/English support.
2. Verified civic-department directory and official escalation paths.
3. Status tracking with authorized department integration.
4. Carefully evaluated text classification, with human review and explainable outputs.
5. Map/location support with explicit consent and privacy protections.
6. Automated tests, deployment pipeline, and accessibility checks.
