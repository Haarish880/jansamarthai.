import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import triage

class TriageTests(unittest.TestCase):
    def test_road_issue_is_normal(self):
        priority, suggestion = triage("Roads", "Pothole on the street")
        self.assertEqual(priority, "Normal")
        self.assertIn("location", suggestion.lower())

    def test_public_safety_is_high(self):
        priority, _ = triage("Public Safety", "Issue near the street")
        self.assertEqual(priority, "High")

    def test_danger_keyword_is_high(self):
        priority, _ = triage("Other", "There is a live wire near the road")
        self.assertEqual(priority, "High")

if __name__ == "__main__":
    unittest.main()
