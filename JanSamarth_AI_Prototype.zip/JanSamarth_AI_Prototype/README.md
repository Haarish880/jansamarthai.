# JanSamarth AI — Automated Grievance & Civic Response System

**Team:** Nexaura  
**HSC Registration ID:** HSC|TN|03572  
**Institution:** Sri Sairam Engineering College  
**Prototype status:** Local demonstration prototype

## What it does
- Accepts a civic grievance category, locality, and description.
- Saves submissions in a local SQLite database.
- Applies transparent, rule-based demo triage (`High` or `Normal`).
- Shows a suggested next step and the ten most recent submissions.

> Important: This prototype does not connect to government systems, send complaints to officials, verify identities, or use a trained AI model. The “AI” title is the project concept; this starter implementation uses simple rules for demonstrability. Do not enter sensitive personal information.

## Requirements
- Python 3.10+
- pip

## Run locally
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 in your browser. The SQLite file `grievances.db` is created locally when the app runs.

Set a different Flask secret key before deployment:
- Windows PowerShell: `$env:FLASK_SECRET_KEY="replace-with-a-long-random-value"`
- macOS/Linux: `export FLASK_SECRET_KEY="replace-with-a-long-random-value"`

## Project structure
```text
JanSamarth_AI_Prototype/
├── app.py
├── requirements.txt
├── README.md
├── LICENSE
├── docs/
│   └── TECHNICAL_DESIGN.md
├── sample_data/
│   └── sample_grievances.json
└── tests/
    └── test_triage.py
```

## Test
```bash
python -m unittest discover -s tests -v
```

## Upload to GitHub
1. Create a new **public** repository named `jansamarth-ai` (only if your team is comfortable making the code public).
2. Extract this ZIP file.
3. In the extracted folder, open a terminal and run:
```bash
git init
git add .
git commit -m "Initial JanSamarth AI prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/jansamarth-ai.git
git push -u origin main
```
4. Replace `YOUR-USERNAME` with your real GitHub username. Then use the real repository URL in the submission form. Do not submit the example URL before the repository exists.

## Before submission
- Run the app and tests on your own computer.
- Add only sample/fake data to the repository; never commit real Aadhaar numbers, phone numbers, passwords, API keys, or real complainants' personal information.
- Add screenshots of the working app and an accurate architecture diagram if the event requires them.
- Verify whether the organizer requires a specific license or public repository setting.
